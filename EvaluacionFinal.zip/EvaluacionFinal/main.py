from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/ejercicio1', methods=['GET', 'POST'])
def ejercicio1():
    if request.method == 'POST':
        # Procesar datos del formulario y calcular descuento
        nombre = request.form['nombre']
        edad = int(request.form['edad'])
        tarros = int(request.form['tarros'])

        # Lógica para calcular descuento
        descuento = 0
        if 18 <= edad <= 30:
            descuento = 0.15
        elif edad > 30:
            descuento = 0.25

        total_sin_descuento = tarros * 9000
        descuento_aplicado = total_sin_descuento * descuento
        total_a_pagar = total_sin_descuento - descuento_aplicado

        return render_template('resultado_ejercicio1.html',
                               nombre=nombre,
                               total_sin_descuento=total_sin_descuento,
                               descuento=descuento_aplicado,
                               total_a_pagar=total_a_pagar)

    return render_template('ejercicio1.html')

@app.route('/ejercicio2', methods=['GET', 'POST'])
def ejercicio2():
    if request.method == 'POST':
        # Verificar usuario y contraseña
        nombre = request.form['nombre']
        password = request.form['password']

        usuarios = {'juan': 'admin', 'pepe': 'user'}

        # Validar si el usuario existe y la contraseña es correcta
        if nombre in usuarios:
            if usuarios[nombre] == password:
                mensaje = f'Bienvenido {"administrador" if nombre == "juan" else "usuario"} {nombre}'
            else:
                mensaje = 'Contraseña incorrecta'
        else:
            mensaje = 'Usuario no encontrado'

        return render_template('resultado_ejercicio2.html', mensaje=mensaje)

    return render_template('ejercicio2.html')

# ...

if __name__ == '__main__':
    app.run(debug=True)

